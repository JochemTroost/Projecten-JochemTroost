<?php
namespace App\Controllers;

use App\Models\Shop;

class ShopController
{
    public function addShop(string $name, string $type, float $revenue = 0.0)
    {
        $shop = new Shop($name, $type, $revenue);
        $shop->save();
    }

    public function getShops(): array
    {
        return Shop::getAll();
    }
}
