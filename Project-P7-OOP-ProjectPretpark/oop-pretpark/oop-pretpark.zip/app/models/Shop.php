<?php
namespace App\models;

use PDO;

class Shop {
    private ?int $id;
    private string $name;
    private string $type;
    private float $revenue;

    public function __construct(string $name, string $type, float $revenue = 0.0, ?int $id = null) {
        $this->name = $name;
        $this->type = $type;
        $this->revenue = $revenue;
        $this->id = $id;
    }

    // Getters & setters
    public function getId(): ?int { return $this->id; }
    public function getName(): string { return $this->name; }
    public function getType(): string { return $this->type; }
    public function getRevenue(): float { return $this->revenue; }

    public function setName(string $name) { $this->name = $name; }
    public function setType(string $type) { $this->type = $type; }
    public function setRevenue(float $revenue) { $this->revenue = $revenue; }

    // Save to DB
    public function save() {
        $pdo = Database::getConnection();

        if ($this->id === null) {
            // Insert new shop
            $stmt = $pdo->prepare("INSERT INTO shops (name, type, revenue) VALUES (:name, :type, :revenue)");
            $stmt->execute([
                ':name' => $this->name,
                ':type' => $this->type,
                ':revenue' => $this->revenue
            ]);
            $this->id = (int)$pdo->lastInsertId();
        } else {
            // Update existing shop
            $stmt = $pdo->prepare("UPDATE shops SET name = :name, type = :type, revenue = :revenue WHERE id = :id");
            $stmt->execute([
                ':name' => $this->name,
                ':type' => $this->type,
                ':revenue' => $this->revenue,
                ':id' => $this->id
            ]);
        }
    }

    // Get all shops
    public static function getAll(): array {
        $pdo = Database::getConnection();
        $stmt = $pdo->query("SELECT * FROM shops");
        $shops = [];
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $shops[] = new Shop($row['name'], $row['type'], (float)$row['revenue'], (int)$row['id']);
        }
        return $shops;
    }
}
