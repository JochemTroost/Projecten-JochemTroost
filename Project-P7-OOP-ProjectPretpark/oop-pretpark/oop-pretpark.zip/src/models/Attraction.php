<?php

namespace System\models;

class Attraction {
    

}