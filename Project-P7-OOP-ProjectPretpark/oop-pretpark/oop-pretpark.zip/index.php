<?php
session_start(); // niet strikt nodig bij DB, maar veilig voor toekomstige uitbreidingen
require __DIR__ . '/vendor/autoload.php';

use App\Controllers\ShopController;

// Controller aanmaken
$shopController = new ShopController();

// Formulier verwerken
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $type = trim($_POST['type'] ?? '');
    $revenue = (float)($_POST['revenue'] ?? 0.0);

    if ($name !== '' && $type !== '') {
        $shopController->addShop($name, $type, $revenue);
        $message = "Shop added successfully!";
    } else {
        $error = "Name and Type are required.";
    }
}

// Alle shops ophalen
$shops = $shopController->getShops();

include __DIR__ . '/src/views/shops.php';
